@debabi_symver@ {
    global: *;
};
