# Code Review

**Scope:** Entire codebase, including the C++ backend, QML interface, tests, build and release scripts, packaging, and CI.
**Date:** 2026-11-17 (revised the same day after a cross-review between Codex and Claude)
**Verdict:** The build, QML lint, and all three CTest cases passed. One packaging defect will break the next AUR release. The other items are real but narrow, and most of them are low priority.

## Action items

### Fix first

1. - [x] **Build the AUR package from the new release's source directory** — `aur/PKGBUILD:29`
   The AUR recipe hard-codes `_srcdir="custom-toolbox-26.11"`. `release.sh` updates the version, archive URL, and checksum but leaves this directory alone, so the metadata checks pass while `build()` and `package()` enter the old directory. The next release will fail on a clean build. Set `_srcdir="${pkgname}-${pkgver#v}"` to match GitHub's archive naming, and delete the copied comment about a dpkg-source `src` directory, which applies only to `arch/PKGBUILD`. Inspecting the tarball on every release is not needed.

2. - [x] **Preserve local Arch configuration on upgrade** — `PKGBUILD:42`, `arch/PKGBUILD:64`, `aur/PKGBUILD:64`
   All three Arch recipes install the user-editable `/etc/custom-toolbox/custom-toolbox.conf` without declaring it in `backup`. An upgrade can overwrite the administrator's editor and layout settings. Add `backup=('etc/custom-toolbox/custom-toolbox.conf')` to each recipe.

3. - [x] **Point the README's Arch build at the isolated wrapper** — `README.md:62`
   In the checkout, makepkg's disposable `srcdir` is the project's own `src/`. The documented `makepkg -si` is safe, but adding `-C` deletes the C++ sources before the build and `-c` deletes them after it, including uncommitted edits. `build.sh:124` and `build.sh:133` already avoid this with a temporary `BUILDDIR`. Document `./build.sh --arch` plus the separate install step instead. The recipe can stay where it is.

4. - [x] **Avoid killing or waiting on active launchers during toolbox shutdown** — `src/launchermodel.cpp:648`
   Tracked launches (all `pkexec` launches, plus every launch when `hideGUI=true`, `:627`) run under a `QProcess` owned by the stack-allocated model (`src/main.cpp:182`). When the model is destroyed at exit, `~QProcess` calls `kill()` and then `waitForFinished(30000)`. After authentication, pkexec has executed the target as root, so an unprivileged toolbox gets `EPERM` and the root application survives, but the toolbox can hang on exit for up to 30 seconds. Same-user tracked commands, such as those launched under `hideGUI`, really are killed. Let tracked processes outlive the model, for example by releasing them in the model's destructor, and keep exit reporting while the toolbox is open.

5. - [x] **Declare the Debian dependency for administrator launches** — `debian/control:11`
   `root` launchers invoke `/usr/bin/pkexec` (`src/launchermodel.cpp:578`), which on Debian 12 and 13 is shipped in its own `pkexec` package and is not a declared dependency. MX installs it by default, so the main impact is on plain Debian. Add `pkexec` to `Depends`, or `pkexec | policykit-1` if older releases are also targeted.

### Low priority

6. - [x] **Never resolve the invoking user to root for `user` launches** — `src/launchermodel.cpp:525`
   This applies only when the toolbox itself was started as root. If it was elevated from an existing root session, `PKEXEC_UID=0` resolves to `root`, and a launcher or editor marked `user` runs as root. This is a failure to drop privileges, not an escalation. Rejecting UID 0 only in `nameForUid` is not enough, because the `SUDO_USER` fallback can still return `root`. Validate the resolved account's numeric UID on every return path, and refuse the launch if no non-root account remains. The launcher (`:580`) and the editor (`:729`) both use this helper.

7. - [x] **Limit AUR release commits to the generated package files** — `release.sh:291`
   `git add .` and the unrestricted commit also pick up edits to the third tracked file (`custom-toolbox.1`) and anything already staged in the AUR checkout. Limit the change check, the staging, and the commit to `PKGBUILD` and `.SRCINFO`. Also move the existing checkout and branch checks (`:311`, `:323`) ahead of the first write, so a wrong branch is rejected before anything is committed to it.

8. - [x] **Retry a tag push that failed on the previous release attempt** — `release.sh:444`
   Because of `set -e`, the first failed push is visible. On a rerun, though, the local tag sends the script down the existing-tag branch, which skips the push (`:489`), and the archive download fails again. Check the exact remote ref with `git ls-remote --exit-code --tags origin "refs/tags/$version"`. Push the local tag when it is missing (exit 2), and abort on a transport error.

9. - [x] **Watch a list's desktop entries even when they currently yield no launchers** — `src/launchermodel.cpp:484`
   Keeping the last usable model when a reload produces no launchers is intentional (commits `50cfa1a`, `ad2531d`), and it should stay. However, when the toolbox starts with the list's only entry set to `Hidden=true`, the early return at `:484` skips `watchDesktopFiles` (`:496`). Removing `Hidden=true` later then leaves the toolbox empty. Install watches for the resolved candidates even on an unsuccessful load. Removing a cached row immediately when its desktop entry is hidden is optional and must not undo the protection against bad list edits.

10. - [x] **Decode desktop-entry strings before displaying or expanding them** — `src/launchermodel.cpp:410`
    The `Name`, `Comment`, and `Icon` values are read verbatim. Real target-system files use escapes, for example `Name[tr]=\sÇözücü Yükleyici` in `mx-codecs.desktop` and `Name[hr]=\sScreenshot` in `xfce4-screenshooter.desktop`, so those locales show a literal `\s`. The same raw value reaches `%c` (`src/launcherparser.cpp:483`). Apply the existing `decodeDesktopString` helper, and keep the full decoded name for `%c` before stripping the display-only `MX ` prefix.

11. - [x] **Resolve a terminal emulator when `x-terminal-emulator` is missing** — `src/launchermodel.cpp:562`
    Terminal entries and the nano editor fallback (`:721`) always call the Debian alternatives name, which does not exist on a plain Arch install. Share a fallback routine (`x-terminal-emulator`, `$TERMINAL`, then common emulators) between both paths. Choose each emulator's correct argument form so arguments stay separate: for example, xfce4-terminal's `-e` takes a single command string, while `-x` takes separate arguments.

12. - [x] **Keep header and view controls reachable at the configured minimum width** — `qml/Main.qml:131`
    At the shipped `min_width=300` (`custom-toolbox.conf:9`), an offscreen check placed About at x=339 and the Hide categories label (`:339`, a separate row) at x=555. Either stack the controls or move secondary actions into a compact menu when they don't fit. Raising the minimum is also valid if narrow windows are no longer supported, but it means updating `README.md:264` and `tests/test_launchermodel.cpp:247`, and it has to fit both rows, not only the header.

13. - [x] **Make the wide-window category list scrollable** — `qml/Main.qml:231`
    The sidebar Repeater sits in a fixed-height column. Typical lists fit, but with many categories the overflow goes past the window (in a test with 30 categories at 1080 × 560, the last button started at y=1086). Put the buttons in a scrollable view above the launch-at-login control.

14. - [x] **Keep a legacy autostart entry attached to the list it runs** — `src/launchermodel.cpp:850`
    `isLegacyAutostartFile` also accepts the canonical path, so opening a symlink with the same base name moves the target's legacy entry onto the symlink and deletes the original (`:906`). Turning the switch off at that point removes the target's login launch. The newer hash-based migration already requires the exact launched path (`:919`, `tests/test_launchermodel.cpp:442`). Apply the same rule to legacy entries.

15. - [x] **Preserve equals signs inside space-separated aliases** — `src/launcherparser.cpp:585`
    `sample alias="Mode=Expert"` works, but the equivalent `sample alias "Mode=Expert"` produces the label `"Mode`, because the line is split at the first `=` before quotes are handled. Split only at an `=` outside quoted text so that both forms (`:645`, `:648`) produce the same alias.
