<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="78"/>
        <source>Open this launcher</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="50"/>
        <source>Configuration error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="153"/>
        <source>Search launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="176"/>
        <source>Search launchers and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="188"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="220"/>
        <source>More options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="284"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="345"/>
        <location filename="../qml/Main.qml" line="651"/>
        <source>Launch at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="352"/>
        <source>Open this toolbox automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="362"/>
        <location filename="../qml/Main.qml" line="661"/>
        <source>Launch this toolbox at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="449"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="451"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="461"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="462"/>
        <source>Choose a launcher to start an application or task</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="476"/>
        <source>%n launcher(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="230"/>
        <location filename="../qml/Main.qml" line="492"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="502"/>
        <source>Use condensed launcher view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="505"/>
        <source>Show more launchers at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="239"/>
        <location filename="../qml/Main.qml" line="524"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="534"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="537"/>
        <source>Use the whole window for launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="634"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="692"/>
        <source>About %1</source>
        <translation type="unfinished">大約 %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="742"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="748"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="756"/>
        <source>License</source>
        <translation type="unfinished">授權條款</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="765"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="112"/>
        <source>Custom Toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">關於本程式</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="208"/>
        <location filename="../qml/Main.qml" line="253"/>
        <source>About...</source>
        <translation>關於……</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="vanished">Alt+A</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="666"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="199"/>
        <location filename="../qml/Main.qml" line="249"/>
        <location filename="../src/launchermodel.cpp" line="874"/>
        <source>Help</source>
        <translation>說明</translation>
    </message>
    <message>
        <source>Alt+H</source>
        <translation type="vanished">Alt+H</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">關閉程式</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="674"/>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="vanished">Alt+C</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="113"/>
        <source>This is a custom launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show this dialog at start up</source>
        <translation type="vanished">開機時顯示本視窗</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">搜尋</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="674"/>
        <location filename="../src/launchermodel.cpp" line="682"/>
        <location filename="../src/launchermodel.cpp" line="704"/>
        <location filename="../src/launchermodel.cpp" line="756"/>
        <location filename="../src/launchermodel.cpp" line="768"/>
        <source>Execution Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="617"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="674"/>
        <source>The selected launcher is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="756"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="768"/>
        <source>Failed to execute command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="704"/>
        <source>Failed to start program: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="70"/>
        <location filename="../src/launchermodel.cpp" line="509"/>
        <location filename="../src/launchermodel.cpp" line="1047"/>
        <source>File Open Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <location filename="../src/launchermodel.cpp" line="496"/>
        <source>File Not Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="654"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="167"/>
        <location filename="../src/launchermodel.cpp" line="496"/>
        <source>The file %1 does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="120"/>
        <source>No terminal emulator is installed in the system directories, so this cannot run as administrator in a terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="121"/>
        <source>No terminal emulator found. Install one or set the TERMINAL environment variable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="509"/>
        <source>Could not open file: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="515"/>
        <location filename="../src/launchermodel.cpp" line="551"/>
        <source>Parse Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="515"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="521"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="551"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="690"/>
        <source>Launcher already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="691"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="874"/>
        <location filename="../src/launchermodel.cpp" line="881"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="952"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="1083"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="vanished">版本：</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="vanished">大約 %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="1038"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="860"/>
        <location filename="../src/launchermodel.cpp" line="866"/>
        <location filename="../src/launchermodel.cpp" line="881"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="804"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="866"/>
        <source>Failed to launch the editor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="831"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">MX Linux 版權所有 (c)</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">%1 許可</translation>
    </message>
    <message>
        <source>%1 Help</source>
        <translation type="vanished">%1 幫助</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="972"/>
        <location filename="../src/launchermodel.cpp" line="983"/>
        <source>Could not write file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="1043"/>
        <source>Could not remove file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>Open List File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="61"/>
        <source>List Files (*.list)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">授權條款</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">變更紀錄</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">關閉（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Custom Toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Error</source>
        <translation>錯誤</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="147"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>您似乎是以 root 身份登錄，請登出並以一般使用者身份登錄以使用此程式。</translation>
    </message>
</context>
</TS>
