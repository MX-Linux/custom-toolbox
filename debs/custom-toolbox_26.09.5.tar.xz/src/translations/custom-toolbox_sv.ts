<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="78"/>
        <source>Open this launcher</source>
        <translation>Öppna denna snabbstartare</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="43"/>
        <source>Configuration error</source>
        <translation>Konfigurationsfel</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="131"/>
        <source>Search launchers</source>
        <translation>Sök snabbstartare</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="154"/>
        <source>Search launchers and tasks…</source>
        <translation>Sök snabbstartare och aktiviteter...</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="166"/>
        <source>Clear search</source>
        <translation>Töm sökning</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="215"/>
        <source>CATEGORIES</source>
        <translation>KATEGORIER</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="251"/>
        <location filename="../qml/Main.qml" line="484"/>
        <source>Launch at login</source>
        <translation>Starta vid inloggning</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>Open this toolbox automatically</source>
        <translation>Öppna denna verktygslåda automatiskt</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <location filename="../qml/Main.qml" line="493"/>
        <source>Launch this toolbox at login</source>
        <translation>Starta denna verktygslåda vid inloggning</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="334"/>
        <source>Search results</source>
        <translation>Sökresultat</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="336"/>
        <source>All launchers</source>
        <translation>Alla snabbstartare</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="343"/>
        <source>Results matching “%1”</source>
        <translation>Resultat som matchar “%1”</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="344"/>
        <source>Choose a launcher to start an application or task</source>
        <translation>Välj en snabbstartare för att starta en applikation eller aktivitet</translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="351"/>
        <source>%n launcher(s)</source>
        <translation>
            <numerusform>%n snabbstart(are)</numerusform>
            <numerusform>%n snabbstart(are)</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="366"/>
        <source>Condensed view</source>
        <translation>Komprimerad vy</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="376"/>
        <source>Use condensed launcher view</source>
        <translation>Använd komprimerad snabbstartarvy</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="379"/>
        <source>Show more launchers at once</source>
        <translation>Visa fler snabbstartare på en gång</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation>Inga snabbstartare hittade
Försök en annan sökning eller kategori.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="523"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="556"/>
        <source>Version %1</source>
        <translation>Version %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="562"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation>Anpassad Toolbox skapar fockuserade sammlingar av applikations-snabbstartare och systemaktiviteter.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="570"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="579"/>
        <source>Copyright © MX Linux</source>
        <translation>Copyright © MX Linux</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="108"/>
        <source>Custom Toolbox</source>
        <translation>Inställbar Verktygslåda</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="184"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="498"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="176"/>
        <location filename="../src/launchermodel.cpp" line="736"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="506"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="109"/>
        <source>This is a custom launcher</source>
        <translation>Detta är en anpassad startare</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="562"/>
        <location filename="../src/launchermodel.cpp" line="569"/>
        <location filename="../src/launchermodel.cpp" line="591"/>
        <location filename="../src/launchermodel.cpp" line="620"/>
        <location filename="../src/launchermodel.cpp" line="632"/>
        <source>Execution Error</source>
        <translation>Utförandefel</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="523"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>Kommandot är tomt. Kan inte utföras.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="562"/>
        <source>The selected launcher is no longer available.</source>
        <translation>Den valda snabbstartaren är inte längre tillgänglig.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="620"/>
        <source>Failed to start command: %1</source>
        <translation>Kunde inte starta kommandot: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="632"/>
        <source>Failed to execute command: %1</source>
        <translation>Misslyckades med att utföra kommando: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="591"/>
        <source>Failed to start program: %1</source>
        <translation>Misslyckades med att starta program: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="70"/>
        <location filename="../src/launchermodel.cpp" line="423"/>
        <location filename="../src/launchermodel.cpp" line="869"/>
        <source>File Open Error</source>
        <translation>Fil-öppningsfel</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <location filename="../src/launchermodel.cpp" line="410"/>
        <source>File Not Found</source>
        <translation>Fil ej hittad</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="544"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation>Kunde inte bestämma den oprivilegierade användaren. Vägrar att köra denna startare som root.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="167"/>
        <location filename="../src/launchermodel.cpp" line="410"/>
        <source>The file %1 does not exist.</source>
        <translation>Filen %1 finns inte.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="423"/>
        <source>Could not open file: </source>
        <translation>Kunde inte öppna fil:</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="429"/>
        <location filename="../src/launchermodel.cpp" line="458"/>
        <source>Parse Error</source>
        <translation>Analysfel</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="429"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>Filen %1 innehåller inga igenkännbara snabbstart poster.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="435"/>
        <source>All launchers</source>
        <translation>Alla snabbstartare</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="458"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Ingen av posterna i %1 matchar en installerad applikation.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="577"/>
        <source>Launcher already running</source>
        <translation>Snabbstartare körs redan</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="578"/>
        <source>%1 is already running.</source>
        <translation>%1 körs redan.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="791"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation>Vägrar att skriva över en non-Custom Toolbox autostart fil: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="860"/>
        <source>Could not create directory: %1</source>
        <translation>Kunde inte skapa katalog: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="722"/>
        <location filename="../src/launchermodel.cpp" line="728"/>
        <location filename="../src/launchermodel.cpp" line="743"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="668"/>
        <source>Editor command is empty.</source>
        <translation>Redigerarens kommando är tomt.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="728"/>
        <source>Failed to launch the editor.</source>
        <translation>Kunde inte starta redigeraren.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="689"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation>Kunde inte bestämma den oprivilegierade användaren. Vägrar att starta redigeraren som root.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="736"/>
        <location filename="../src/launchermodel.cpp" line="743"/>
        <source>Could not open %1.</source>
        <translation>Kunde inte öppna %1.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="898"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation>Kunde inte ladda om konfiguration. Den tidigare konfigurationen används fortfarande.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="811"/>
        <location filename="../src/launchermodel.cpp" line="822"/>
        <source>Could not write file: %1</source>
        <translation>Kunde inte skriva fil: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="865"/>
        <source>Could not remove file: %1</source>
        <translation>Kunde inte ta bort fil: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>Open List File</source>
        <translation>Öppna Listfil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="61"/>
        <source>List Files (*.list)</source>
        <translation>Listfiler (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Kunde inte öppna fil. Vill du försöka igen?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Custom Toolbox</source>
        <translation>Inställbar Verktygslåda</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Denna app kan användas för att skapa anpassade startare: låda med knappar/ikoner</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Visa inte &apos;visa denna dialog vid start &apos; kryssruta</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Full sökväg och namnet på den  .list fil du vill ladda. Stöder både anpassat format (Key=Value) och INI format ([Section]).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="147"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du verkar vara inloggad som rot, var vänlig logga ut och logga in som vanlig användare för att använda detta program.</translation>
    </message>
</context>
</TS>
