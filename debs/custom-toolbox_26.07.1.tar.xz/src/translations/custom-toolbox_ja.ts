<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ja">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="106"/>
        <source>Custom Toolbox</source>
        <translation>カスタムツールボックス</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>このアプリケーションについて</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>情報...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>ランチャのカスタマイズ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>編集</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>アプリの終了</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>これはカスタムランチャです</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>起動時にこのダイヤログを表示する</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Execution Error</source>
        <translation>実行時のエラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>コマンドが空です。実行できません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Failed to execute command: %1</source>
        <translation>次のコマンドの実行に失敗しました: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Failed to start program: %1</source>
        <translation>次のプログラムの起動に失敗しました: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <location filename="../src/main.cpp" line="66"/>
        <source>File Open Error</source>
        <translation>ファイルを開く際のエラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="153"/>
        <source>File Not Found</source>
        <translation>ファイルが見つかりません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="528"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="154"/>
        <source>The file %1 does not exist.</source>
        <translation>ファイル %1 は存在しません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Could not open file: </source>
        <translation>次のファイルを開けません: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Parse Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="653"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="699"/>
        <source>Version:</source>
        <translation>バージョン:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="702"/>
        <source>About %1</source>
        <translation> %1 について</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Directory Creation Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="774"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Failed to launch the editor.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="910"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>カスタムツールボックスは、カスタムランチャの作成ツールです。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="703"/>
        <source>%1 License</source>
        <translation>%1 ライセンス</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>%1 ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <source>Could not write file: %1</source>
        <translation>次のファイルに書き込めません：%1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>File Removal Error</source>
        <translation>ファイルの削除エラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Could not remove file: %1</source>
        <translation>次のファイルを削除できません: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Open List File</source>
        <translation>リストファイルを開く</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="57"/>
        <source>List Files (*.list)</source>
        <translation>リストファイル (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>ファイルを開けません。再試行しますか？</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <location filename="../src/about.cpp" line="111"/>
        <source>Changelog</source>
        <translation>更新履歴</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="118"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="56"/>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>このアプリでカスタムランチャ（ボタン/アイコンのボックス）を作成できます。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>「起動時にこのダイアログを表示する」チェックボックスを表示しない</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>root としてログインしているようです。このプログラムを使用するには、一度ログアウトして通常のユーザとしてログインしてください。</translation>
    </message>
</context>
</TS>