<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="de">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="106"/>
        <source>Custom Toolbox</source>
        <translation>Benutzerdefinierte Werkzeuge</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Programmstarter anpassen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Anwendung schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Dies ist ein benutzerdefinierter Programmstarter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Diesen Dialog beim Start anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>Suche </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Execution Error</source>
        <translation>Fehler bei Ausführung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>Befehl ist leer. Nicht ausführbar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Failed to start command: %1</source>
        <translation>Befehl konnte nicht gestartet werden: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Failed to execute command: %1</source>
        <translation>Befehl konnte nicht ausgeführt werden: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Failed to start program: %1</source>
        <translation>Programm konnte nicht gestartet werden: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <location filename="../src/main.cpp" line="66"/>
        <source>File Open Error</source>
        <translation>Fehler beim Öffnen der Datei</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="153"/>
        <source>File Not Found</source>
        <translation>Datei nicht gefunden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="528"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="154"/>
        <source>The file %1 does not exist.</source>
        <translation>Die Datei %1 existiert nicht.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Could not open file: </source>
        <translation>Konnte Datei nicht öffnen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Parse Error</source>
        <translation>Fehler beim Parsen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>Datei %1 enthält keine erkennbaren Starteingaben.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="653"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Keine der Eingaben bei %1 entspricht einem installierten Programm.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="699"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="702"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Directory Creation Error</source>
        <translation>Fehler beim Erzeugen des Verzeichnisses</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="774"/>
        <source>Could not create directory: %1</source>
        <translation>Verzeichnis konnte nicht angelegt werden: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>Editor command is empty.</source>
        <translation>Editorbefehl ist leer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Failed to launch the editor.</source>
        <translation>Fehler beim Start des Editors.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="910"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Custom Toolbox ist ein Werkzeug, mit dem ein eigener Programmstarter erstellt werden kann</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="703"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <source>Could not write file: %1</source>
        <translation>Die Datei konnte nicht geschrieben werden: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>File Removal Error</source>
        <translation>Fehler beim Entfernen der Datei</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Could not remove file: %1</source>
        <translation>Die Datei konnte nicht entfernt werden: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Open List File</source>
        <translation>Eine List-Datei öffnen</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="57"/>
        <source>List Files (*.list)</source>
        <translation>List-Dateien (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Konnte Datei nicht öffnen, möchten Sie es erneut versuchen?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>Could not load %1</source>
        <translation>%1 konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <location filename="../src/about.cpp" line="111"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="118"/>
        <source>Could not load changelog.</source>
        <translation>Änderungsprotokoll konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="56"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Diese Anwendung kann verwendet werden, um benutzerdefinierte Programmstarter zu erstellen: Box mit Schaltflächen/Symbolen</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Das Kontrollkästchen &quot;Diesen Dialog beim Startvorgang zeigen&quot; nicht anzeigen</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Vollständiger Pfad und Name der zu öffnenden .list Datei. Sowohl Custom Format (Taste=Wert) als auch INI Format ([Section]) werden unterstützt.
</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sie sind als Administrator am System angemeldet. Bitte melden Sie sich ab und dann als normaler Benutzer wieder an, um dieses Programm zu verwenden.</translation>
    </message>
</context>
</TS>