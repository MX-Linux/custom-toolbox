<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="106"/>
        <source>Custom Toolbox</source>
        <translation>Пользовательский набор инструментов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Настроить лаунчер</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Закрыть приложение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Это настраиваемый лаунчер</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Показывать этот диалог при запуске</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Execution Error</source>
        <translation>Ошибка выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>Команда пуста. Невозможно выполнить.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Failed to start command: %1</source>
        <translation>Не удалось запустить команду: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Failed to execute command: %1</source>
        <translation>Не удалось выполнить команду: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Failed to start program: %1</source>
        <translation>Не удалось запустить программу: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <location filename="../src/main.cpp" line="66"/>
        <source>File Open Error</source>
        <translation>Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="153"/>
        <source>File Not Found</source>
        <translation>Файл не найден</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="528"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="154"/>
        <source>The file %1 does not exist.</source>
        <translation>Файл %1 не существует.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Could not open file: </source>
        <translation>Не удалось открыть файл:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Parse Error</source>
        <translation>Ошибка разбора</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>Файл% 1 не содержит распознаваемых записей программы запуска.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="653"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Ни одна из записей в% 1 не соответствует установленному приложению.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="699"/>
        <source>Version:</source>
        <translation>Версия:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="702"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Directory Creation Error</source>
        <translation>Ошибка создания каталога</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="774"/>
        <source>Could not create directory: %1</source>
        <translation>Не удалось создать каталог: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>Editor command is empty.</source>
        <translation>Команда редактора пуста.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Failed to launch the editor.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="910"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Пользовательский набор инструментов - это инструмент, используемый для создания пользовательского лаунчера</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="703"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <source>Could not write file: %1</source>
        <translation>Не удалось записать файл: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>File Removal Error</source>
        <translation>Ошибка удаления файла</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Could not remove file: %1</source>
        <translation>Не удалось удалить файл: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Open List File</source>
        <translation>Открыть файл списка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="57"/>
        <source>List Files (*.list)</source>
        <translation>Файлы списка (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Не могу открыть файл. Хотите попробовать еще раз?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <location filename="../src/about.cpp" line="111"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="118"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="56"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Это приложение можно использовать для создания настраиваемых лаунчеров: бокс с кнопками/иконками</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Не показывать флажок «показывать этот диалог при запуске»</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Полный путь и имя файла «.list», который вы хотите загрузить. Поддерживает как пользовательский формат (Ключ=Значение), так и формат INI ([Раздел]).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
</context>
</TS>