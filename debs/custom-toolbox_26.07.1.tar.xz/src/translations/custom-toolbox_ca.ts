<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ca">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="106"/>
        <source>Custom Toolbox</source>
        <translation>Caixa d&apos;Eines personalitzada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Quant a aquest programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Quant a...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Personalitza el llançador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Ajuda </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Surt de l&apos;aplicació </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Aquest és un llançador personalitzat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Mostra aquest diàleg en engegar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>cerca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Execution Error</source>
        <translation>Error d&apos;execució</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="215"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>L&apos;ordre és buida. No es pot executar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>Failed to start command: %1</source>
        <translation>Ha fallat iniciar l&apos;ordre: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Failed to execute command: %1</source>
        <translation>Ha fallat en executar l&apos;ordre: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>Failed to start program: %1</source>
        <translation>Ha fallat en engegar el programa: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <location filename="../src/main.cpp" line="66"/>
        <source>File Open Error</source>
        <translation>Error en obrir el fitxer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="153"/>
        <source>File Not Found</source>
        <translation>No he trobat el fitxer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="528"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation>No he pogut determinar l&apos;usuari sense privilegis. S&apos;evita executar aquest llançador com a administrador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="589"/>
        <location filename="../src/main.cpp" line="154"/>
        <source>The file %1 does not exist.</source>
        <translation>El fitxer %1 no existeix.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Could not open file: </source>
        <translation>No s&apos;ha pogut obrir el fitxer: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Parse Error</source>
        <translation>Analitza l&apos;error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>El fitxer %1 no conté cap entrada executable identificable.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="653"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Cap de les entrades a %1 coincideix amb una aplicació instal·lada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="699"/>
        <source>Version:</source>
        <translation>Versió: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="702"/>
        <source>About %1</source>
        <translation>Quant a %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="773"/>
        <source>Directory Creation Error</source>
        <translation>Error de creació del directori</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="774"/>
        <source>Could not create directory: %1</source>
        <translation>No s&apos;ha pogut crear el directori: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>Editor command is empty.</source>
        <translation>L&apos;ordre de l&apos;editor està buida.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <source>Failed to launch the editor.</source>
        <translation>Ha fallat en executar l&apos;editor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="910"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation>No he pogut determinar l&apos;usuari sense privilegis. S&apos;evita executar aquest editor com a administrador.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Custom Toolbox és una eina usada per crear llançadors personalitzats</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="703"/>
        <source>%1 License</source>
        <translation>Llicència de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>%1 Help</source>
        <translation>Ajuda de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="809"/>
        <source>Could not write file: %1</source>
        <translation>No puc escriure al fitxer: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>File Removal Error</source>
        <translation>Error d&apos;eliminació de fitxer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>Could not remove file: %1</source>
        <translation>No puc eliminar el fitxer: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Open List File</source>
        <translation>Obre el fitxer de Llista</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="57"/>
        <source>List Files (*.list)</source>
        <translation>Fitxers de Llista (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>No puc obrir el fitxer, voleu reintentar-ho?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>Could not load %1</source>
        <translation>No s&apos;ha pogut carregar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>License</source>
        <translation>Llicència</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <location filename="../src/about.cpp" line="111"/>
        <source>Changelog</source>
        <translation>Registre de canvis</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="118"/>
        <source>Could not load changelog.</source>
        <translation>No s&apos;ha pogut carregar el registre de canvis.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="56"/>
        <source>&amp;Close</source>
        <translation>Tan&amp;ca </translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Aquesta app es pot usar per crear llançadors personalitzats: capses de botons/icones</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>No mostris la casella de selecció &apos;mostra aquest diàleg en arrencar&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Camí sencer i nom del fitxer .list que voleu carregar. Admet tant el format personalitzat (Clau=Valor) com l&apos;INI ([Secció]).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembla que esteu connectat com a administrador, si us plau sortiu i connecteu-vos com a usuari normal per a usar aquest programa.</translation>
    </message>
</context>
</TS>