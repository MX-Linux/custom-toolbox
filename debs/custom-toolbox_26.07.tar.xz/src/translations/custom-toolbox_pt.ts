<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="100"/>
        <source>Custom Toolbox</source>
        <translation>Ferramentas Personalizadas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Sobre esta aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Personalizar lançador </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Fechar a aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Isto é um lançador personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Mostrar esta janela ao iniciar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>procurar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Execution Error</source>
        <translation>Erro de execução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>O comando está em branco. Não há nada para executar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <source>Failed to start command: %1</source>
        <translation>Falha ao iniciar o comando: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <source>Failed to execute command: %1</source>
        <translation>Falha ao executar o comando: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Failed to start program: %1</source>
        <translation>Falha ao iniciar o programa: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="557"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <location filename="../src/main.cpp" line="66"/>
        <source>File Open Error</source>
        <translation>Erro ao abrir ficheiro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/main.cpp" line="153"/>
        <source>File Not Found</source>
        <translation>Ficheiro não encontrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/main.cpp" line="154"/>
        <source>The file %1 does not exist.</source>
        <translation>O ficheiro %1 não existe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="557"/>
        <source>Could not open file: </source>
        <translation>Não foi possível abrir o ficheiro:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="566"/>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <source>Parse Error</source>
        <translation>Erro ao analisar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>O ficheiro %1 não contém entradas de lançador reconhecíveis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="595"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Nenhuma entrada em %1 corresponde a um programa instalado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Version:</source>
        <translation>Versão:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <source>Directory Creation Error</source>
        <translation>Erro ao Criar Directório</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <source>Could not create directory: %1</source>
        <translation>Não foi possível criar o directório: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="738"/>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="738"/>
        <source>Editor command is empty.</source>
        <translation>O editor de comandos está em branco.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>Failed to launch the editor.</source>
        <translation>Erro ao abrir o editor.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Esta ferramenta serve para criar um lançador personalizado </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Copyright (c) MX Linux</source>
        <translation> Direitos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="639"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Could not write file: %1</source>
        <translation>Não foi possível gravar o ficheiro: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="725"/>
        <source>File Removal Error</source>
        <translation>Ocorreu um erro ao remover o ficheiro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="725"/>
        <source>Could not remove file: %1</source>
        <translation>Não foi possível remover o ficheiro: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Open List File</source>
        <translation>Abrir lista de ficheiros</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="57"/>
        <source>List Files (*.list)</source>
        <translation>Listar ficheiros (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Não foi possível abrir o ficheiro. Tentar novamente?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>Foi impossível carregar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Registo de alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Falha ao carregar registo de alterações.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Esta aplicação pode ser utilizada para criar lançadores personalizados: caixa de botões/ícones</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Ocultar caixa de seleção &apos;Exibir esta janela ao iniciar&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Caminho completo e nome do ficheiro .list a carregar. Suporta formato personalizado (Key=Value [Tecla=Valor])  e o formato ‘INI format ([Section]) (formato INI ([Secção])).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="134"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O utilizador parece ser o root; para usar este programa, sair e voltar a entrar como utilizador normal.</translation>
    </message>
</context>
</TS>