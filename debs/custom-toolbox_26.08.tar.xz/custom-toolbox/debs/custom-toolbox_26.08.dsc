Format: 3.0 (native)
Source: custom-toolbox
Binary: custom-toolbox
Architecture: any
Version: 26.08
Maintainer: Adrian <adrian@mxlinux.org>
Standards-Version: 4.5.1
Vcs-Git: git://github.com/AdrianTM/custom-toolbox
Build-Depends: debhelper-compat (= 12), cmake (>= 3.16), ninja-build, qt6-base-dev, qt6-base-dev-tools, qt6-declarative-dev, qt6-tools-dev, qt6-tools-dev-tools
Package-List:
 custom-toolbox deb admin optional arch=any
Checksums-Sha1:
 1c1f0730b474711d08acecca22cce614bd4f4cf0 1531972 custom-toolbox_26.08.tar.xz
Checksums-Sha256:
 4e4b37326e67a45d5905125336bea899bb0ff562e9b35472b1dd01b120f8f866 1531972 custom-toolbox_26.08.tar.xz
Files:
 6440cb10d1439104b4fc05a8b278ae00 1531972 custom-toolbox_26.08.tar.xz
