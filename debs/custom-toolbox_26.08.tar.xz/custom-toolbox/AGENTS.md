# Repository Guidelines

Custom Toolbox is a C++20/Qt 6 Linux application launcher. Qt Quick implements its interface; C++ handles parsing, launcher discovery, execution, and filesystem monitoring.

## Project Structure & Module Organization

- `src/`: C++ backend. `LauncherModel` exposes data/actions to QML, `LauncherParser` reads custom and INI `.list` formats, and `IconLoader` resolves icons.
- `qml/`: Qt Quick UI. `Main.qml` owns the application window and layout; reusable controls live in `qml/components/`.
- `tests/`: Qt Test suites for the parser and model, plus the CMake install-layout smoke test.
- `translations/`: Qt Linguist `.ts` catalogs. Desktop-file translations live in `translations-desktop-file/`.
- `icons/` and `help/`: artwork, HTML help, and the man page.
- `debian/`, `PKGBUILD`, and `release.sh`: packaging and release metadata.

## Build, Test, and Development Commands

- `./build.sh`: configure and compile a Release build with Ninja.
- `./build.sh --debug`, `--clang`, or `--clean`: select Debug, Clang, or a clean rebuild.
- `cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel`: equivalent direct build.
- `cmake --build build --target all_qmllint`: lint all QML files.
- `ctest --test-dir build --output-on-failure`: run all tests.
- `./build/custom-toolbox example.list`: run with the sample configuration.
- `./build.sh --debian` or `./build.sh --arch`: produce distribution packages.

Qt packages must include Core, Gui, Widgets, Qml, Quick, QuickControls2, Test, and LinguistTools. Use GCC 14+ or Clang 15+.

## Architecture and Configuration

`main.cpp` loads translations and injects `LauncherModel` into `QQmlApplicationEngine`. Keep business logic in C++ and presentation/state binding in QML. Runtime configuration comes from `/etc/custom-toolbox/custom-toolbox.conf`; launcher definitions use `/etc/custom-toolbox/*.list` or an explicit path. Preserve the existing `pkexec` flow; never add implicit privileged actions.

## Coding Style & Naming Conventions

Use four-space indentation, no trailing whitespace, and match nearby code. Classes use `PascalCase`; methods, variables, QML IDs, and properties use `camelCase`. Warnings are errors, so keep GCC and Clang clean. Translate C++ UI text with `tr()`/`QCoreApplication::translate()` and QML text with `qsTr()`/`qsTranslate()`; update relevant `.ts` catalogs.

## Testing Guidelines

Tests use Qt Test and follow `tests/test_<component>.cpp`. Add focused cases for parser or model behavior. Before submitting, build, run `all_qmllint`, and run CTest. Manually launch `example.list` for UI changes.

## Commit & Pull Request Guidelines

Use concise, imperative commit subjects such as `Fix QML lint dependencies in CI`; keep unrelated changes separate. Pull requests should explain the change and rationale, link relevant issues, list build/test commands run, and include screenshots for Qt Quick UI changes.
