<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sq">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <source>Custom Toolbox</source>
        <translation>Grup Vetjak Mjetesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Mbi këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Mbi…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Përshtatni nisësin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Përpunoni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Mbylle aplikacionin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Ky është një nisës vetjak</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Shfaqe këtë dialog gjatë nisjes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>kërko</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <location filename="../src/mainwindow.cpp" line="269"/>
        <location filename="../src/mainwindow.cpp" line="277"/>
        <location filename="../src/mainwindow.cpp" line="294"/>
        <location filename="../src/mainwindow.cpp" line="302"/>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>Execution Error</source>
        <translation>Gabim Ekzekutimi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>Urdhri është i zbrazët. S’mund të përmbushet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="269"/>
        <source>Failed to start command: %1</source>
        <translation>S’u arrit të nisej urdhër: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="277"/>
        <location filename="../src/mainwindow.cpp" line="302"/>
        <source>Failed to execute command: %1</source>
        <translation>S’u arrit të ekzekutohet urdhër: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="294"/>
        <location filename="../src/mainwindow.cpp" line="312"/>
        <source>Failed to start program: %1</source>
        <translation>S’u arrit të nisej program: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="352"/>
        <source>Open List File</source>
        <translation>Hap Kartelën Listë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="352"/>
        <source>List Files (*.list)</source>
        <translation>Kartela Listë (*.list)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <source>File Selection Error</source>
        <translation>Gabim Përzgjedhjeje Kartele</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="354"/>
        <source>No file selected. Application will now exit.</source>
        <translation>S’u përzgjodh kartelë. Aplikacioni tani do të mbyllet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="360"/>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <location filename="../src/mainwindow.cpp" line="803"/>
        <source>File Open Error</source>
        <translation>Gabim Hapje Kartele</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="361"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>S’u hap dot kartelë. Doni të riprovohet?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>File Not Found</source>
        <translation>Kartela S’u Gjet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>The file %1 does not exist.</source>
        <translation>Kartela %1 s’ekziston.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>Could not open file: </source>
        <translation>S’u hap dot kartelë:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="733"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="736"/>
        <source>About %1</source>
        <translation>Mbi %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>Directory Creation Error</source>
        <translation>Gabim Krijimi Drejtorie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="786"/>
        <source>Could not create directory: %1</source>
        <translation>S’u krijua dot drejtori: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <source>Editor command failed with code %1</source>
        <translation>Urdhri i përpunuesit dështoi me kod %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="734"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Grupi Vetjak i Mjeteve është një mjet i përdorur për të krijuar nisës vetjakë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="734"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Të drejta kopjimi (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="737"/>
        <source>%1 License</source>
        <translation>Licencë %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>%1 Help</source>
        <translation>Ndihmë për %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="803"/>
        <source>Could not write file: %1</source>
        <translation>S’u shkrua dot kartelë: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="808"/>
        <source>File Removal Error</source>
        <translation>Gabim Heqjeje Kartele</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="808"/>
        <source>Could not remove file: %1</source>
        <translation>S’u hoq dot kartelë: %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>S’u ngarkua dot %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licencë</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Regjistër ndryshimesh</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>S’u ngarkua dot regjistër ndryshimesh.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Ky aplikacion mund të përdoret për të krijuar nisës vetjakë: kuti butonash/ikonash</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Kutizë për mosshfaqje të “shfaqe këtë dialog gjatë nisjes”</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="91"/>
        <source>Full path and name of the .list file you want to load to set up the application</source>
        <translation>Shteg i plotë dhe emër i kartelës listë që dëshironi të ngarkohet për të ujdisur aplikacionin</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Duket të jeni futur si rrënjë, ju lutemi, që të përdorni këtë program, dilni nga llogaria dhe hyni si përdorues i zakonshëm.</translation>
    </message>
</context>
</TS>