const QString VERSION {"26.05"};
