<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="118"/>
        <source>Custom Toolbox</source>
        <translation>Custom Toolbox</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>About this application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Customize launcher</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Close application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>This is a custom launcher</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Show this dialog at start up</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>search</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <source>Execution Error</source>
        <translation>Execution Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="203"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>Command is empty. Cannot execute.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="180"/>
        <source>Failed to start command: %1</source>
        <translation>Failed to start command: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Failed to execute command: %1</source>
        <translation>Failed to execute command: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="214"/>
        <source>Failed to start program: %1</source>
        <translation>Failed to start program: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <source>Open List File</source>
        <translation>Open List File</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <source>List Files (*.list)</source>
        <translation>List Files (*.list)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>File Selection Error</source>
        <translation>File Selection Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>No file selected. Application will now exit.</source>
        <translation>No file selected. Application will now exit.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="262"/>
        <location filename="../src/mainwindow.cpp" line="558"/>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>File Open Error</source>
        <translation>File Open Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="263"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Could not open file. Do you want to try again?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="80"/>
        <location filename="../src/mainwindow.cpp" line="524"/>
        <source>File Not Found</source>
        <translation>File Not Found</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="80"/>
        <location filename="../src/mainwindow.cpp" line="524"/>
        <source>The file %1 does not exist.</source>
        <translation>The file %1 does not exist.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="558"/>
        <source>Could not open file: </source>
        <translation>Could not open file: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="606"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>About %1</source>
        <translation>About %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <source>Directory Creation Error</source>
        <translation>Directory Creation Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="658"/>
        <source>Could not create directory: %1</source>
        <translation>Could not create directory: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="709"/>
        <location filename="../src/mainwindow.cpp" line="729"/>
        <source>Error</source>
        <translation>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="709"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="729"/>
        <source>Editor command failed with code %1</source>
        <translation>Editor command failed with code %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Custom Toolbox is a tool used for creating a custom launcher</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="610"/>
        <source>%1 License</source>
        <translation>%1 License</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="616"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Could not write file: %1</source>
        <translation>Could not write file: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="696"/>
        <source>File Removal Error</source>
        <translation>File Removal Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="696"/>
        <source>Could not remove file: %1</source>
        <translation>Could not remove file: %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>License</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>This app can be used to create custom launchers: box of buttons/icons</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="91"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>Error</source>
        <translation>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>You seem to be logged in as root, please log out and log in as normal user to use this program.</translation>
    </message>
</context>
</TS>