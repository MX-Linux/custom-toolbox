<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="78"/>
        <source>Open this launcher</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="43"/>
        <source>Configuration error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="131"/>
        <source>Search launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="154"/>
        <source>Search launchers and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="166"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="215"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="251"/>
        <location filename="../qml/Main.qml" line="484"/>
        <source>Launch at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>Open this toolbox automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <location filename="../qml/Main.qml" line="493"/>
        <source>Launch this toolbox at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="334"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="336"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="343"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="344"/>
        <source>Choose a launcher to start an application or task</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="351"/>
        <source>%n launcher(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="366"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="376"/>
        <source>Use condensed launcher view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="379"/>
        <source>Show more launchers at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="523"/>
        <source>About %1</source>
        <translation type="unfinished">Περί του %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="556"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="562"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="570"/>
        <source>License</source>
        <translation type="unfinished">Άδεια</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="579"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="108"/>
        <source>Custom Toolbox</source>
        <translation>Προσαρμοσμένη Εργαλειοθήκη</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">Περί της εφαρμογής</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="184"/>
        <source>About...</source>
        <translation>Περί...</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="vanished">Alt+A</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="498"/>
        <source>Edit</source>
        <translation>Επεξεργασία</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="176"/>
        <location filename="../src/launchermodel.cpp" line="736"/>
        <source>Help</source>
        <translation>Βοήθεια</translation>
    </message>
    <message>
        <source>Alt+H</source>
        <translation type="vanished">Alt+H</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">Κλείσιμο εφαρμογής</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="506"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="vanished">Alt+C</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="109"/>
        <source>This is a custom launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show this dialog at start up</source>
        <translation type="vanished">Εμφάνιση αυτού του παραθύρου στην εκκίνηση</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">αναζήτηση</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="562"/>
        <location filename="../src/launchermodel.cpp" line="569"/>
        <location filename="../src/launchermodel.cpp" line="591"/>
        <location filename="../src/launchermodel.cpp" line="620"/>
        <location filename="../src/launchermodel.cpp" line="632"/>
        <source>Execution Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="523"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="562"/>
        <source>The selected launcher is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="620"/>
        <source>Failed to start command: %1</source>
        <translation>Απέτυχε η εκκίνηση της εντολής: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="632"/>
        <source>Failed to execute command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="591"/>
        <source>Failed to start program: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="423"/>
        <location filename="../src/launchermodel.cpp" line="869"/>
        <location filename="../src/main.cpp" line="70"/>
        <source>File Open Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="410"/>
        <location filename="../src/main.cpp" line="171"/>
        <source>File Not Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="544"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="410"/>
        <location filename="../src/main.cpp" line="172"/>
        <source>The file %1 does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="423"/>
        <source>Could not open file: </source>
        <translation>Δεν ήταν δυνατό το άνοιγμα του αρχείου:</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="429"/>
        <location filename="../src/launchermodel.cpp" line="458"/>
        <source>Parse Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="429"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="435"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="458"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="577"/>
        <source>Launcher already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="578"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="736"/>
        <location filename="../src/launchermodel.cpp" line="743"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="791"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="898"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="vanished">Έκδοση:</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="vanished">Περί του %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="860"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="722"/>
        <location filename="../src/launchermodel.cpp" line="728"/>
        <location filename="../src/launchermodel.cpp" line="743"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="668"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="728"/>
        <source>Failed to launch the editor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="689"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">Πνευματικά δικαιώματα (c) MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">Άδεια %1</translation>
    </message>
    <message>
        <source>%1 Help</source>
        <translation type="vanished">Βοήθεια %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="811"/>
        <location filename="../src/launchermodel.cpp" line="822"/>
        <source>Could not write file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="865"/>
        <source>Could not remove file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>Open List File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="61"/>
        <source>List Files (*.list)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Could not load %1</source>
        <translation type="vanished">Δεν ήταν δυνατή η φόρτωση του %1</translation>
    </message>
    <message>
        <source>License</source>
        <translation type="vanished">Άδεια</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Αρχείο αλλαγών</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Άκυρο</translation>
    </message>
    <message>
        <source>Could not load changelog.</source>
        <translation type="vanished">Δεν ήταν δυνατή η φόρτωση του αρχείου αλλαγών.</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Custom Toolbox</source>
        <translation type="unfinished">Προσαρμοσμένη Εργαλειοθήκη</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="138"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="140"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="151"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="152"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Φαίνεται ότι έχετε συνδεθεί ως διαχειριστής, αποσυνδεθείτε και συνδεθείτε ως απλός χρήστης για να χρησιμοποιήσετε αυτό το πρόγραμμα.</translation>
    </message>
</context>
</TS>
