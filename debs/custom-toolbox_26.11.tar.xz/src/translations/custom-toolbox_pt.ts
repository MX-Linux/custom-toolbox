<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="78"/>
        <source>Open this launcher</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="44"/>
        <source>Configuration error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="141"/>
        <source>Search launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="164"/>
        <source>Search launchers and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="176"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="225"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="261"/>
        <location filename="../qml/Main.qml" line="522"/>
        <source>Launch at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <source>Open this toolbox automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="278"/>
        <location filename="../qml/Main.qml" line="531"/>
        <source>Launch this toolbox at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="344"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="346"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="353"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="354"/>
        <source>Choose a launcher to start an application or task</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="361"/>
        <source>%n launcher(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="376"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="386"/>
        <source>Use condensed launcher view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="389"/>
        <source>Show more launchers at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="404"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="414"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="417"/>
        <source>Use the whole window for launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="510"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="561"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="594"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="600"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="608"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="617"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="108"/>
        <source>Custom Toolbox</source>
        <translation>Ferramentas Personalizadas</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="194"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="536"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="186"/>
        <location filename="../src/launchermodel.cpp" line="780"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="544"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="109"/>
        <source>This is a custom launcher</source>
        <translation>Isto é um lançador personalizado</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="604"/>
        <location filename="../src/launchermodel.cpp" line="612"/>
        <location filename="../src/launchermodel.cpp" line="634"/>
        <location filename="../src/launchermodel.cpp" line="664"/>
        <location filename="../src/launchermodel.cpp" line="676"/>
        <source>Execution Error</source>
        <translation>Erro de execução</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="549"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>O comando está em branco. Não há nada para executar.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="604"/>
        <source>The selected launcher is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="664"/>
        <source>Failed to start command: %1</source>
        <translation>Falha ao iniciar o comando: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="676"/>
        <source>Failed to execute command: %1</source>
        <translation>Falha ao executar o comando: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="634"/>
        <source>Failed to start program: %1</source>
        <translation>Falha ao iniciar o programa: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="70"/>
        <location filename="../src/launchermodel.cpp" line="446"/>
        <location filename="../src/launchermodel.cpp" line="953"/>
        <source>File Open Error</source>
        <translation>Erro ao abrir ficheiro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <location filename="../src/launchermodel.cpp" line="433"/>
        <source>File Not Found</source>
        <translation>Ficheiro não encontrado</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="584"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="167"/>
        <location filename="../src/launchermodel.cpp" line="433"/>
        <source>The file %1 does not exist.</source>
        <translation>O ficheiro %1 não existe.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="446"/>
        <source>Could not open file: </source>
        <translation>Não foi possível abrir o ficheiro:</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="452"/>
        <location filename="../src/launchermodel.cpp" line="483"/>
        <source>Parse Error</source>
        <translation>Erro ao analisar</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="452"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>O ficheiro %1 não contém entradas de lançador reconhecíveis.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="458"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="483"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Nenhuma entrada em %1 corresponde a um programa instalado.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="620"/>
        <source>Launcher already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="621"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="858"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="944"/>
        <source>Could not create directory: %1</source>
        <translation>Não foi possível criar o directório: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="766"/>
        <location filename="../src/launchermodel.cpp" line="772"/>
        <location filename="../src/launchermodel.cpp" line="787"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="712"/>
        <source>Editor command is empty.</source>
        <translation>O editor de comandos está em branco.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="772"/>
        <source>Failed to launch the editor.</source>
        <translation>Erro ao abrir o editor.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="733"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="780"/>
        <location filename="../src/launchermodel.cpp" line="787"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="989"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="878"/>
        <location filename="../src/launchermodel.cpp" line="889"/>
        <source>Could not write file: %1</source>
        <translation>Não foi possível gravar o ficheiro: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="949"/>
        <source>Could not remove file: %1</source>
        <translation>Não foi possível remover o ficheiro: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>Open List File</source>
        <translation>Abrir lista de ficheiros</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="61"/>
        <source>List Files (*.list)</source>
        <translation>Listar ficheiros (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Não foi possível abrir o ficheiro. Tentar novamente?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Custom Toolbox</source>
        <translation>Ferramentas Personalizadas</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Esta aplicação pode ser utilizada para criar lançadores personalizados: caixa de botões/ícones</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Ocultar caixa de seleção &apos;Exibir esta janela ao iniciar&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Caminho completo e nome do ficheiro .list a carregar. Suporta formato personalizado (Key=Value [Tecla=Valor])  e o formato ‘INI format ([Section]) (formato INI ([Secção])).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="147"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O utilizador parece ser o root; para usar este programa, sair e voltar a entrar como utilizador normal.</translation>
    </message>
</context>
</TS>
