<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="78"/>
        <source>Open this launcher</source>
        <translation>Откройте этот лаунчер</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="44"/>
        <source>Configuration error</source>
        <translation>Ошибка конфигурации</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="141"/>
        <source>Search launchers</source>
        <translation>Поиск лаунчеров</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="164"/>
        <source>Search launchers and tasks…</source>
        <translation>Поиск лаунчеров и задач...</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="176"/>
        <source>Clear search</source>
        <translation>Очистить поиск</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="225"/>
        <source>CATEGORIES</source>
        <translation>КАТЕГОРИИ</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="261"/>
        <location filename="../qml/Main.qml" line="522"/>
        <source>Launch at login</source>
        <translation>Запуск при входе в систему</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <source>Open this toolbox automatically</source>
        <translation>Открывать этот набор инструментов автоматически</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="278"/>
        <location filename="../qml/Main.qml" line="531"/>
        <source>Launch this toolbox at login</source>
        <translation>Запустить этот набор инструментов при входе в систему</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="344"/>
        <source>Search results</source>
        <translation>Результаты поиска</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="346"/>
        <source>All launchers</source>
        <translation>Все лаунчеры</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="353"/>
        <source>Results matching “%1”</source>
        <translation>Результаты, совпадающие “%1”</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="354"/>
        <source>Choose a launcher to start an application or task</source>
        <translation>Выберите лаунчер для запуска приложения или задачи</translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="361"/>
        <source>%n launcher(s)</source>
        <translation>
            <numerusform>%n лаунчер()</numerusform>
            <numerusform>%n лаунчер(ов)</numerusform>
            <numerusform>%n лаунчер(ов)</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="376"/>
        <source>Condensed view</source>
        <translation>Компактный вид</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="386"/>
        <source>Use condensed launcher view</source>
        <translation>Используйте компактный вид панели запуска</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="389"/>
        <source>Show more launchers at once</source>
        <translation>Показать больше лаунчеров</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="404"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="414"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="417"/>
        <source>Use the whole window for launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="510"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation>Лаунчеры не найдены
Попробуйте другой поиск или категорию.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="561"/>
        <source>About %1</source>
        <translation>О программе %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="594"/>
        <source>Version %1</source>
        <translation>Версия %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="600"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation>Custom Toolbox создает специализированные наборы средств запуска приложений и системных задач.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="608"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="617"/>
        <source>Copyright © MX Linux</source>
        <translation>Copyright © MX Linux</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="108"/>
        <source>Custom Toolbox</source>
        <translation>Пользовательский набор инструментов</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="194"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="536"/>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="186"/>
        <location filename="../src/launchermodel.cpp" line="780"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="544"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="109"/>
        <source>This is a custom launcher</source>
        <translation>Это настраиваемый лаунчер</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="604"/>
        <location filename="../src/launchermodel.cpp" line="612"/>
        <location filename="../src/launchermodel.cpp" line="634"/>
        <location filename="../src/launchermodel.cpp" line="664"/>
        <location filename="../src/launchermodel.cpp" line="676"/>
        <source>Execution Error</source>
        <translation>Ошибка выполнения</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="549"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>Команда пуста. Невозможно выполнить.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="604"/>
        <source>The selected launcher is no longer available.</source>
        <translation>Выбранный лаунчер больше не доступен.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="664"/>
        <source>Failed to start command: %1</source>
        <translation>Не удалось запустить команду: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="676"/>
        <source>Failed to execute command: %1</source>
        <translation>Не удалось выполнить команду: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="634"/>
        <source>Failed to start program: %1</source>
        <translation>Не удалось запустить программу: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="70"/>
        <location filename="../src/launchermodel.cpp" line="446"/>
        <location filename="../src/launchermodel.cpp" line="953"/>
        <source>File Open Error</source>
        <translation>Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <location filename="../src/launchermodel.cpp" line="433"/>
        <source>File Not Found</source>
        <translation>Файл не найден</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="584"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation>Не удалось определить обычного пользователя. Отказ от запуска этого лаунчера от root.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="167"/>
        <location filename="../src/launchermodel.cpp" line="433"/>
        <source>The file %1 does not exist.</source>
        <translation>Файл %1 не существует.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="446"/>
        <source>Could not open file: </source>
        <translation>Не удалось открыть файл:</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="452"/>
        <location filename="../src/launchermodel.cpp" line="483"/>
        <source>Parse Error</source>
        <translation>Ошибка разбора</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="452"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>Файл %1 не содержит распознаваемых записей лаунчера.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="458"/>
        <source>All launchers</source>
        <translation>Все лаунчеры</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="483"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Ни одна из записей в %1 не соответствует установленному приложению.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="620"/>
        <source>Launcher already running</source>
        <translation>Лаунчер уже запущен</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="621"/>
        <source>%1 is already running.</source>
        <translation>%1 уже запущен.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="858"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation>Отказ от перезаписи файла автозапуска, не являющегося пользовательским набором инструментов: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="944"/>
        <source>Could not create directory: %1</source>
        <translation>Не удалось создать каталог: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="766"/>
        <location filename="../src/launchermodel.cpp" line="772"/>
        <location filename="../src/launchermodel.cpp" line="787"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="712"/>
        <source>Editor command is empty.</source>
        <translation>Команда редактора пуста.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="772"/>
        <source>Failed to launch the editor.</source>
        <translation>Не удалось запустить редактор.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="733"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation>Не удалось определить обычного пользователя. Отказ от запуска редактора от root.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="780"/>
        <location filename="../src/launchermodel.cpp" line="787"/>
        <source>Could not open %1.</source>
        <translation>Не удалось открыть %1.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="989"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation>Не удалось перезагрузить конфигурацию. Предыдущая конфигурация всё ещё используется.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="878"/>
        <location filename="../src/launchermodel.cpp" line="889"/>
        <source>Could not write file: %1</source>
        <translation>Не удалось записать файл: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="949"/>
        <source>Could not remove file: %1</source>
        <translation>Не удалось удалить файл: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>Open List File</source>
        <translation>Открыть файл списка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="61"/>
        <source>List Files (*.list)</source>
        <translation>Файлы списков (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Не удалось открыть файл. Попробовать ещё раз?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>Custom Toolbox</source>
        <translation>Пользовательский набор инструментов</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="130"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Это приложение можно использовать для создания пользовательских лаунчеров: набор кнопок/значков</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Не показывать флажок «показывать это окно при запуске»</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Полный путь и имя файла .list, который вы хотите загрузить. Поддерживает как пользовательский формат (Ключ=Значение), так и формат INI ([Раздел]).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="147"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Вы вошли в систему как root. Пожалуйста, выйдите и войдите как обычный пользователь для использования этой программы.</translation>
    </message>
</context>
</TS>
