# Code Review

**Scope:** Entire codebase, including C++ and QML sources, tests, helper scripts, build configuration, packaging, and CI; excluding generated artifacts, translation catalogs, and third-party code.
**Date:** 2026-11-13
**Verdict:** Four reproducible correctness issues remain, including unintended privilege flags from INI aliases, despite a successful build, QML lint, and all three CTest tests.

## Action items

1. - [x] **Preserve INI alias boundaries before interpreting privilege flags** — `src/launcherparser.cpp:399`
   A literal INI entry `items=sample:alias="My:root:Tool"` is decoded by QSettings as `sample:alias=My:root:Tool`, so this split truncates the alias to `My` and sets `root=true`, causing an unintended pkexec authorization request and an elevated launch if approved. Preserve quoted alias boundaries before QSettings removes the quotes, and test literal INI file contents; the existing test writes through QSettings, which escapes the quotes and misses this failure.
2. - [x] **Honor the desktop entry's working directory** — `src/launchermodel.cpp:611`
   Desktop entries' `Path=` values are never loaded, and both detached and tracked launches inherit the toolbox's working directory: a probe using `Exec=/bin/pwd` and `Path=/tmp/<fixture>/work` printed the repository directory instead. Applications using relative resource or input paths therefore fail or access the wrong files; retain `Path` in ItemInfo and pass it to `startDetached` or `QProcess::setWorkingDirectory` for every launch mode.
3. - [x] **Keep autostart identity stable when a list symlink changes** — `src/launchermodel.cpp:771`
   Enable autostart for `link.list` pointing to `one.list`, retarget it to `two.list`, then disable autostart: the canonical-path hash changes, so the removal checks a different filename, reports the switch as disabled, and leaves the original autostart entry active. Use a stable identity for the opened list path or retain and remove the exact managed autostart file created before the symlink changed.
4. - [x] **Watch desktop-file contents as well as application directories** — `src/launchermodel.cpp:951`
   Only application directories are watched, so editing an existing `.desktop` file in place does not trigger a reload; a reproduced Name change remained stale until the `.list` file was touched, and Exec changes follow the same stale-data path. Watch the resolved desktop files themselves, restore watches after replacement, and cover relevant subdirectories so displayed metadata and launch commands update when those files change.
