<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nb">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="110"/>
        <source>Custom Toolbox</source>
        <translation>Selvvalgt verktøykasse</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Om …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt + A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Tilpass snarvei</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt + E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt + H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Lukk program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt + C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Dette er en tilpasset snarvei</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Vis dette vinduet ved oppstart</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>søk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <location filename="../src/mainwindow.cpp" line="196"/>
        <location filename="../src/mainwindow.cpp" line="207"/>
        <source>Execution Error</source>
        <translation>Kjørefeil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="196"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="179"/>
        <source>Failed to execute command: %1</source>
        <translation>Klarte ikke kjøre kommando: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="207"/>
        <source>Failed to start program: %1</source>
        <translation>Klarte ikke starte program: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="247"/>
        <source>Open List File</source>
        <translation>Åpne listefil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="247"/>
        <source>List Files (*.list)</source>
        <translation>Listefiler (*.list)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <source>File Selection Error</source>
        <translation>Feil ved valg av fil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <source>No file selected. Application will now exit.</source>
        <translation>Ingen fil valgt. Programmet vil nå avslutte.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <location filename="../src/mainwindow.cpp" line="571"/>
        <location filename="../src/mainwindow.cpp" line="727"/>
        <source>File Open Error</source>
        <translation>Feil ved åpning av fil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="256"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Klarte ikke åpne fil. Forsøke igjen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="82"/>
        <location filename="../src/mainwindow.cpp" line="551"/>
        <source>File Not Found</source>
        <translation>Fant ikke fil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="82"/>
        <location filename="../src/mainwindow.cpp" line="551"/>
        <source>The file %1 does not exist.</source>
        <translation>Fila %1 finnes ikke.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="571"/>
        <source>Could not open file: </source>
        <translation>Klarte ikke åpne fil:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="578"/>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>Parse Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="579"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="605"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="643"/>
        <source>Version:</source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="646"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="693"/>
        <source>Directory Creation Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="694"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="745"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="765"/>
        <source>Editor command failed with code %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Selvvalgt Verktøykasse er et verktøy for å lage egne snarveier</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Opphavsrett (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="647"/>
        <source>%1 License</source>
        <translation>Lisens for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>%1 Help</source>
        <translation>Hjelpetekst for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="727"/>
        <source>Could not write file: %1</source>
        <translation>Klarte ikke skrive til fil: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="732"/>
        <source>File Removal Error</source>
        <translation>Feil ved fjerning av fil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="732"/>
        <source>Could not remove file: %1</source>
        <translation>Klarte ikke fjerne fil: %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Lisens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Endringslogg</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Dette programmet kan brukes for å lage egne snarveier: Bokser med knapper/ikoner</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Ikke vis avkryssingsboks for «Vis dette dialogvinduet ved oppstart»</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="91"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du er innlogget som root. Vennligst logg ut, og logg inn igjen som en vanlig bruker for å bruke dette programmet.</translation>
    </message>
</context>
</TS>