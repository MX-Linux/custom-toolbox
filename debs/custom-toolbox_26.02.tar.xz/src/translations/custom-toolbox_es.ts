<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="207"/>
        <source>Custom Toolbox</source>
        <translation>Caja de herramientas personalizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Personalizar lanzadores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Cerrar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Este es un lanzador personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Mostrar esta ventana al inicio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <source>Execution Error</source>
        <translation>Error de ejecución</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>El comando está vacío. No se puede ejecutar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <source>Failed to execute command: %1</source>
        <translation>Fallo al ejecutar el comando: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <source>Failed to start program: %1</source>
        <translation>Fallo al iniciar el programa: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="344"/>
        <source>Open List File</source>
        <translation>Abrir archivo de lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="344"/>
        <source>List Files (*.list)</source>
        <translation>Archivos de lista (*.list)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>File Selection Error</source>
        <translation>Error de selección de archivos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>No file selected. Application will now exit.</source>
        <translation>No se seleccionó ningún archivo. La aplicación se cerrará.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="352"/>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>File Open Error</source>
        <translation>Error al abrir el archivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>No se pudo abrir el archivo, ¿quiere intentarlo de nuevo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>File Not Found</source>
        <translation>Archivo no encontrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>The file %1 does not exist.</source>
        <translation>El archivo %1 no existe. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <source>Could not open file: </source>
        <translation>No se pudo abrir el archivo:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Version:</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Directory Creation Error</source>
        <translation>Error de creación de directorio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="763"/>
        <source>Could not create directory: %1</source>
        <translation>No se pudo crear el directorio: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Editor command failed with code %1</source>
        <translation>El comando del editor falló con el código %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Personalizar lanzadores es una herramienta utilizada para crear un lanzador personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="714"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="721"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>Could not write file: %1</source>
        <translation>No se pudo escribir el archivo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>File Removal Error</source>
        <translation>Error en la eliminación de archivos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>Could not remove file: %1</source>
        <translation>No se pudo eliminar el archivo %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <source>Failed to start mx-viewer</source>
        <translation>No se pudo iniciar mx-viewer</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <source>Failed to start xdg-open</source>
        <translation>No se pudo iniciar xdg-open</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="62"/>
        <source>Failed to determine user name. Cannot open document.</source>
        <translation>No se pudo determinar el nombre de usuario. No se puede abrir el documento.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="64"/>
        <source>Failed to start runuser</source>
        <translation>No se pudo iniciar runuser</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="79"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="80"/>
        <location filename="../src/about.cpp" line="90"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="81"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Esta aplicación se puede utilizar para crear lanzadores personalizados: caja de botones/iconos</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>No mostrar la casilla &apos;Mostrar este cuadro de diálogo al inicio&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>Full path and name of the .list file you want to load to set up the application</source>
        <translation>Ruta completa y nombre del archivo .list que desea cargar para configurar la aplicación</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="61"/>
        <location filename="../src/about.cpp" line="64"/>
        <location filename="../src/main.cpp" line="100"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
</context>
</TS>