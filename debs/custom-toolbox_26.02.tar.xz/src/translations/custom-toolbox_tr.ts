<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="207"/>
        <source>Custom Toolbox</source>
        <translation>Özel Araç Kutusu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Uygulama hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Hakkında...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Başlatıcıyı özelleştir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Düzenle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Uygulamayı kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Bu özel bir başlatıcıdır</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Bu pencereyi her açılışta göster</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>Ara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <source>Execution Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <source>Failed to execute command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <source>Failed to start program: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="344"/>
        <source>Open List File</source>
        <translation>Liste Dosyasını Aç</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="344"/>
        <source>List Files (*.list)</source>
        <translation>Liste Dosyaları (*.list)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>File Selection Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>No file selected. Application will now exit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="352"/>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>File Open Error</source>
        <translation>Dosya Açılırken Hata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>File Not Found</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>The file %1 does not exist.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <source>Could not open file: </source>
        <translation>Dosya açılamadı:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Version:</source>
        <translation>Sürüm:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>About %1</source>
        <translation>%1 Hakkında </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Directory Creation Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="763"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Editor command failed with code %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Custom Toolbox, özel bir başlatıcı oluşturmak için kullanılan bir araçtır</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Telif Hakkı (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="714"/>
        <source>%1 License</source>
        <translation>%1 Lisans</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="721"/>
        <source>%1 Help</source>
        <translation>%1 Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>Could not write file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>File Removal Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>Could not remove file: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <source>Failed to start mx-viewer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <source>Failed to start xdg-open</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="62"/>
        <source>Failed to determine user name. Cannot open document.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="64"/>
        <source>Failed to start runuser</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="79"/>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="80"/>
        <location filename="../src/about.cpp" line="90"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="81"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Bu uygulama, özel başlatıcı oluşturmak için kullanılabilir: düğme/simge kutusu</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>&quot;Bu iletişim kutusunu başlangıçta göster&quot; onay kutusunu gösterme</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>Full path and name of the .list file you want to load to set up the application</source>
        <translation>Uygulamayı kurmak için yüklemek istediğiniz .list dosyasının tam yolu ve adı</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="61"/>
        <location filename="../src/about.cpp" line="64"/>
        <location filename="../src/main.cpp" line="100"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Görünüşe göre root olarak girmişsiniz, lütfen çıkın ve bu programı kullanmak için normal kullanıcı olarak girin. </translation>
    </message>
</context>
</TS>