<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="207"/>
        <source>Custom Toolbox</source>
        <translation>Caixa de ferramentas personalizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Personalizar lanzador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Cerrar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Este é un lanzador personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Amosar esta lapela ao iniciar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>busca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <source>Execution Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="255"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="274"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <source>Failed to execute command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="304"/>
        <source>Failed to start program: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="344"/>
        <source>Open List File</source>
        <translation>Abrir ficheiro de lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="344"/>
        <source>List Files (*.list)</source>
        <translation>Listar Ficheiros (*.list)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>File Selection Error</source>
        <translation>Erro na selección de ficheiros</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="346"/>
        <source>No file selected. Application will now exit.</source>
        <translation>Non se seleccionou ningún ficheiro. A aplicación sairá agora.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="352"/>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>File Open Error</source>
        <translation>Erro ao abrir o ficheiro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="353"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Non se puido abrir o ficheiro, queres intentalo de novo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>File Not Found</source>
        <translation>Ficheiro non atopado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>The file %1 does not exist.</source>
        <translation>O ficheiro %1 non existe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="622"/>
        <source>Could not open file: </source>
        <translation>Non foi posible abrir o ficheiro:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="710"/>
        <source>Version:</source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="713"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="762"/>
        <source>Directory Creation Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="763"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <source>Editor command failed with code %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Caixa de ferramentas personalizada é unha ferramenta utilizada para crear un lanzador personalizado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="711"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="714"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="721"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <source>Could not write file: %1</source>
        <translation>Non se puido escribir o ficheiro: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>File Removal Error</source>
        <translation>Erro na eliminación de ficheiros</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>Could not remove file: %1</source>
        <translation>Non foi posíbel eliminar o ficheiro: % 1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <source>Failed to start mx-viewer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <source>Failed to start xdg-open</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="62"/>
        <source>Failed to determine user name. Cannot open document.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="64"/>
        <source>Failed to start runuser</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="79"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="80"/>
        <location filename="../src/about.cpp" line="90"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="81"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="103"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Esta aplicación pode ser utilizada para crear lanzadores personalizados: caixa de botóns/iconas</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Non amosar a caixa de verificación &apos;amosar este diálogo ao iniciar&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>Full path and name of the .list file you want to load to set up the application</source>
        <translation>Ruta completa e nome do ficheiro .list que desexa cargar para configurar a aplicación</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="48"/>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="61"/>
        <location filename="../src/about.cpp" line="64"/>
        <location filename="../src/main.cpp" line="100"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O usuario parece ser root; para usar este programa, pechar a sesión e iniciar sesión como usuario normal.</translation>
    </message>
</context>
</TS>