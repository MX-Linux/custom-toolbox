# Repository Guidelines

Custom Toolbox is a Qt6-based application launcher for Linux that builds customizable launcher interfaces from simple text-based `.list` configuration files. It targets MX Linux but runs on any Linux distribution.

## Project Structure & Modules
- `src/`: C++/Qt sources (`main.cpp`, `mainwindow.*`, `flatbutton.*`, `launcherparser.*`, `iconloader.*`, `about.*`, `mainwindow.ui`).
- `translations/`: Qt `.ts` files compiled to `.qm` at build time.
- `icons/`, `help/`: assets bundled via `images.qrc`.
- `CMakeLists.txt`: Qt6/C++20 build; auto MOC/UIC/RCC.
- `build.sh`: primary build helper; `debian/` and `PKGBUILD` for packaging.
- `example.list`, `custom-toolbox.conf`: config samples for runtime.

## Build, Test, Run
- Build (Release, GCC): `./build.sh`
- Build (Debug): `./build.sh --debug`
- Build (Clang): `./build.sh --clang`
- Clean rebuild: `./build.sh --clean`
- Debian package: `./build.sh --debian` (artifacts in `debs/`)
- Arch package: `./build.sh --arch` (uses `PKGBUILD`)
- CMake/Ninja (alt): `cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel` (install with `sudo cmake --install build`)
- Run locally: `./build/custom-toolbox` (file picker) or `./build/custom-toolbox example.list`
- Debug logging: `QT_LOGGING_RULES="*=true" ./build/custom-toolbox`

### Requirements
- C++20 standard (concepts, ranges, designated initializers).
- Qt6 (Core, Gui, Widgets, LinguistTools).
- CMake 3.16+ with Ninja generator.
- GCC 14+ or Clang 15+.

### Build Features
- Strict warnings: `-Wpedantic -Werror` (all warnings are errors).
- Release: `-O3` with LTO (GCC `-flto=auto`, Clang `-flto=thin`).
- Automatic MOC/UIC/RCC via `CMAKE_AUTO*` variables.
- Version extracted from `debian/changelog` (or `PROJECT_VERSION_OVERRIDE` for Arch).

## Architecture
### Core Components
- **MainWindow** (`mainwindow.cpp/h`) — central orchestrator: reads/parses `.list` files, manages UI state and lifecycle, and watches files via `QFileSystemWatcher` with a debounced timer for auto-reload. The grid layout adjusts column count to window width unless fixed via `fixed_number_columns`. Performance caches: `IconLoader`'s icon cache, `desktop_file_cache` (app name → resolved `.desktop` path), and the lazy `desktop_file_index` (Exec / reverse-DNS fallback). Parsing regexes are `static const QRegularExpression` locals.
- **FlatButton** (`flatbutton.cpp/h`) — styled flat `QPushButton` with hover effects; shows icon, name, and comment tooltip; stores its command in the `cmd` property.
- **LauncherParser** (`launcherparser.*`) — parses both the custom `Key=Value` format and standard INI into a `ParseResult`; extracts localized fields.
- **IconLoader** (`iconloader.*`) — theme-aware icon resolution with caching.
- **Configuration**: `.list` files and `custom-toolbox.conf` under `/etc/custom-toolbox/`; app metadata from `/usr/share/applications/*.desktop`.

### Data Flow
1. **Init** (`main.cpp` → `MainWindow::setup()`): parse CLI args or prompt for a `.list` file; load `custom-toolbox.conf`; apply the root-login guard.
2. **Parse** (`MainWindow::read_file()` → `LauncherParser::parse()` / `parse_ini()`): detect format and parse into items; resolve each against installed `.desktop` files into `category_map` (`QMultiMap<QString, ItemInfo>`). Each `ItemInfo` holds name, comment, icon_name, exec, and terminal/root/user flags.
3. **Desktop resolution** (`get_desktop_file_name()` / `get_desktop_file_info()`): locate the matching `.desktop`, extract localized Name/Comment/Icon/Exec, cache results.
4. **UI build** (`add_buttons()`): rebuild the grid, add bold category headers, create a `FlatButton` per app, wrap the command via `prepare_command()`, connect to `btn_clicked()`.
5. **Launch** (`btn_clicked()`): read the `cmd` property and run it — `QProcess::startDetached()` normally, or synchronously (`run_synchronous()`) when the command uses `pkexec` or `hideGUI` is set.

### Key Algorithms
- **Icon resolution** (`IconLoader::loadIcon()`): theme lookup via `QIcon::fromTheme()`, fallback search across icon directories, cached for reuse.
- **Command preparation** (`prepare_command()`): prepends `x-terminal-emulator -e` for terminal apps and a `pkexec env DISPLAY=… XAUTHORITY=…` wrapper for root apps; supports user demotion when running as root.
- **File watching** (`watch_file()`, `handle_file_changed()`): watches the `.list` file and its directory, debounces rapid changes, then reloads and rebuilds the UI.

## Configuration File Format
### `.list` structure
```ini
Name=Launcher Title
Comment=Optional description
Theme=icon-theme-name              # Optional: override system icon theme

Category=Category Name
app-name
another-app root                   # Run with root privileges
terminal-app terminal              # Run in terminal
both-flags root terminal           # Both root and terminal
aliased-app alias 'Custom Name'    # Override display name
```
Both this custom `Key=Value` format and standard INI (`[Section]`) are supported.

### Application flags
- `root`: launch with `pkexec` (elevated privileges).
- `user`: launch as the invoking user (when custom-toolbox runs as root).
- `terminal`: launch in `x-terminal-emulator`.
- `alias 'Name'`: override the displayed name from the desktop file.

### `custom-toolbox.conf` options
- `hideGUI=true/false`: hide the window when launching apps.
- `min_height`, `min_width`: minimum window dimensions.
- `icon_size`: button icon size in pixels.
- `gui_editor`: path to the text editor for the "Edit" button.
- `fixed_number_columns`: fix the column count instead of auto-sizing (e.g. `fixed_number_columns=3`).

## Coding Style & Naming
- Language: C++20 with Qt6 (Core, Gui, Widgets).
- Warnings are treated as errors; keep code pedantic and clean.
- Naming: `PascalCase` classes; `snake_case` functions and variables in the core sources (`mainwindow`, `main`, `flatbutton`), while `about.cpp` uses `camelCase`. Match the surrounding file.
- Indentation: spaces, consistent with surrounding code; no trailing whitespace.
- Formatting: no enforced formatter in repo—mirror current style in diffs.
- Use `tr()` for all user-facing strings.

## Translation System
- Source: `translations/*.ts` (Qt Linguist format), compiled to `.qm` via `qt6_add_translations()`.
- Installed to `/usr/share/custom-toolbox/locale/`, loaded at runtime based on system locale.
- If you change user-visible text, update the `.ts` files with Qt Linguist tools as appropriate.

## Testing Guidelines
- No unit test suite; perform manual QA:
  - Build Release and Debug (GCC and Clang) and run the app.
  - Verify it loads `.list` files from `/etc/custom-toolbox/` (use `example.list` as a template).
  - Check UI actions, root/terminal launch flags, and translations.

## Commit & PR Guidelines
- Commits: concise, imperative mood (e.g., "Fix Edit button", "Remove unused include"). Group related changes.
- PRs: include a clear description, rationale, test notes, and screenshots for UI changes. Reference related issues.
- CI/build: ensure `./build.sh` succeeds and the binary runs before requesting review.

## Security & Config Tips
- Do not introduce privileged actions outside existing `pkexec` flows.
- Read configuration from `/etc/custom-toolbox/` and user config; avoid hardcoded paths.
- Keep performance in mind (startup and icon lookups are hot paths).
- Root handling: the app detects a root *login* (not `sudo`/`pkexec`) and refuses to run.

## File Locations
**Runtime**
- `.list` configs: `/etc/custom-toolbox/*.list`
- Global config: `/etc/custom-toolbox/custom-toolbox.conf`
- Desktop files: `/usr/share/applications/*.desktop`
- User autostart: `~/.config/autostart/[name].desktop`

**Build output**
- Executable: `build/custom-toolbox`
- Translations: `build/*.qm`
- Compile commands: `build/compile_commands.json`

## Development Notes
- UI is defined in `mainwindow.ui` but rarely changes (no Qt Designer required).
- Caches are critical for fast startup with many apps.
- Real-time search filtering via `text_search_text_changed()`.
- Versioning is auto-extracted from `debian/changelog` (first line) via regex or `dpkg-parsechangelog`.
