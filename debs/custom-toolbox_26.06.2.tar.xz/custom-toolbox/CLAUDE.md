# CLAUDE.md

Project guidance for AI agents now lives in [AGENTS.md](AGENTS.md).

Please refer to that file for the project overview, build/run commands, architecture, configuration file format, conventions, and development notes.
