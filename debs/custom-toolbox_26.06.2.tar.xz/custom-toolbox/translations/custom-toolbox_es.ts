<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="100"/>
        <source>Custom Toolbox</source>
        <translation>Caja de herramientas personalizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="72"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="88"/>
        <source>Customize launcher</source>
        <translation>Personalizar lanzadores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="91"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="97"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="167"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Close application</source>
        <translation>Cerrar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="183"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="189"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="303"/>
        <source>This is a custom launcher</source>
        <translation>Este es un lanzador personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Show this dialog at start up</source>
        <translation>Mostrar esta ventana al inicio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="341"/>
        <source>search</source>
        <translation>buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Execution Error</source>
        <translation>Error de ejecución</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="186"/>
        <source>Command is empty. Cannot execute.</source>
        <translation>El comando está vacío. No se puede ejecutar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="163"/>
        <source>Failed to start command: %1</source>
        <translation>No se pudo iniciar el comando: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <source>Failed to execute command: %1</source>
        <translation>Fallo al ejecutar el comando: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Failed to start program: %1</source>
        <translation>Fallo al iniciar el programa: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="557"/>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <location filename="../src/main.cpp" line="68"/>
        <source>File Open Error</source>
        <translation>Error al abrir el archivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/main.cpp" line="155"/>
        <source>File Not Found</source>
        <translation>Archivo no encontrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/main.cpp" line="156"/>
        <source>The file %1 does not exist.</source>
        <translation>El archivo %1 no existe. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="557"/>
        <source>Could not open file: </source>
        <translation>No se pudo abrir el archivo:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="566"/>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <source>Parse Error</source>
        <translation>Error de análisis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation>El archivo %1 no contiene entradas de lanzador reconocibles.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="595"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation>Ninguna de las entradas de %1 coincide con una aplicación instalada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="635"/>
        <source>Version:</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="638"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <source>Directory Creation Error</source>
        <translation>Error de creación de directorio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="686"/>
        <source>Could not create directory: %1</source>
        <translation>No se pudo crear el directorio: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="738"/>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="738"/>
        <source>Editor command is empty.</source>
        <translation>El comando del editor está vacío.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="757"/>
        <source>Failed to launch the editor.</source>
        <translation>No se pudo iniciar el editor.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Personalizar lanzadores es una herramienta utilizada para crear un lanzador personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="636"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="639"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="644"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="719"/>
        <source>Could not write file: %1</source>
        <translation>No se pudo escribir el archivo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="725"/>
        <source>File Removal Error</source>
        <translation>Error en la eliminación de archivos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="725"/>
        <source>Could not remove file: %1</source>
        <translation>No se pudo eliminar el archivo %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Open List File</source>
        <translation>Abrir archivo de lista</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="57"/>
        <source>List Files (*.list)</source>
        <translation>Archivos de lista (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>File Selection Error</source>
        <translation>Error de selección de archivos</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <source>No file selected. Application will now exit.</source>
        <translation>No se seleccionó ningún archivo. La aplicación se cerrará.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="69"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>No se pudo abrir el archivo, ¿quiere intentarlo de nuevo?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Esta aplicación se puede utilizar para crear lanzadores personalizados: caja de botones/iconos</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="122"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>No mostrar la casilla &apos;Mostrar este cuadro de diálogo al inicio&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="124"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation>Ruta completa y nombre del archivo .list que desea cargar. Admite tanto el formato personalizado (Clave=Valor) como el formato INI ([Sección]).</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="135"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
</context>
</TS>